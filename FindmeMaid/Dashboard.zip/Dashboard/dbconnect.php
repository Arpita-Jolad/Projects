<?php
$conn=mysqli_connect('localhost','id19512328_arpita_jolad','}hqC%^4?9+]n]wdz','id19512328_library_management_system');

?>