<?php
include('dbconnect.php');
if(isset($_POST['SUBMIT']))
{
    $V1=$_POST['f1'];
    $V2=$_POST['f2'];
    $V3=$_POST['f3'];
    $V4=$_POST['f4'];
    $V5=$_POST['f5'];
    $V6=$_POST['f6'];
    $V7=$_POST['f7'];
        $V8=$_POST['f8'];
           
                      
    
    
    $sql = mysqli_query ($conn,"INSERT INTO MAID_DETAILS VALUES('$V1','$V2','$V3','$V4','$V5','$V6','$V7','$V8')");
    
}


?>










<html>
    <head>
        <title>
            Maid details

        </title>
    </head>
    <body>
        <h1>Fill all the details </h1>
        <form method="POST">
            <label>MAID_ID</label>
            <input type="text" name="f1" /><br>

            <label>M_NAME</label>  
            <input type="text" name="f2" /> <br>

            <label>CATEGORY</label>   
            <select name="f3" >
                <option></option>
                <option>BABY-CARE</option>
                <option>WASHING</option>
                <option>CLEANING</option>
                <option>COOKING</option>
                </select>
                <br>
               
                
                    <label>MOBILE</label>  
                    <input type="text" name="f4" /> 
                    <br>
                    <label>CITY</label>  
                    <input type="text" name="f5" />  
                    <br>
                    <label>ADDRESS</label>  
                    <input type="text" name="f6" /> 
                    <br>
                    <label>WORK_DETAILS</label>  
                    <input type="text" name="f7" />  
                    <br>
                   
                    <label>PRICING</label>  
                    <input type="text" name="f8" /> 
                    <br> 
                   
                   
                   <input type="SUBMIT" name="SUBMIT" value="SUBMIT" />

                    

        </form>
    </body>
</html>