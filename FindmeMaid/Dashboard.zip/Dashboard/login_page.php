<?php
 include('dbconnect.php');
if(isset($_POST['submit']))
{
    $v1=$_POST['f1'];
    $v2=$_POST['f2'];
    
    
    $v1=stripcslashes($v1); 
     $v2=stripcslashes($v2);
      
     $v1=mysqli_real_escape_string($conn,$v1);
     $v2=mysqli_real_escape_string($conn,$v2);
     
     $sql="select * from ADMIN where MOBILE_NO='$v1' and PASSWORD='$v2'";
     $result=mysqli_query($conn,$sql);
     $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
     $count = mysqli_num_rows($result);  
          
        if($count == 1){  
            echo "<h1><center> Login successful </center></h1>";  
            
            
            echo"<script>window.open('homepage.php','_self')</script>";  
        }  
        else{  
        
            echo "<h1> Login failed. Invalid mobile number or password</h1>";  
        } 

}

?>



















<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>login page</title>
    
  </head>
  <body style="background-color:#f9cd49">
      
    
        <!-- <div class="col-md-4">
          <div class="card " style="width:500px; height:700px; border-radius: 30PX  ; background-color: blue" >
            <img class="card-img-top " src="maidlogo.png" alt="cardimg" style="width:200px; height:200px; margin:150px;">
            <div class="card-body">
               
            </div>
          </div>

        </div>
    
         -->


         
      <form method="POST">
          <h1>FindmeMaid</h1>
      
          <section class="vh-100 gradient-custom">
      <div class="container py-5 h-100">
        <div class="row d-flex justify-content-center align-items-center h-100">
          <div class="col-12 col-md-8 col-lg-6 col-xl-5">
            <div class="card bg-light text-dark" style="border-radius: 1rem;">
              <div class="card-body p-5 text-center">
    
                <div class="mb-md-3 mt-md-2 ">
                    
                
                    <h2 class="fw-bold mb-2 ">Login Please!</h2>
    
                  <!-- <h2 class="fw-bold mb-2 text-uppercase">Login</h2>
                  <p class="text-dark-50 mb-5">Please enter your mobileno and password!</p>
                   -->
                   <br>
                   
                   <div class="form-outline form-white mb-4">
                    <input type="mobileno" id="typemobileX" class="form-control form-control-lg" name="f1"/>
                    <label class="form-label" for="typeMobileX">Mobile Number</label>
                  </div>
    
                 
                  <div class="form-outline form-white mb-4">
                    <input type="password" id="typePasswordX" class="form-control form-control-lg" name="f2"/>
                    <label class="form-label" for="typePasswordX">Password</label>
                  </div>
                  <br>
                  
    
            
    
                  <input class="btn btn-outline-dark btn-lg px-5" type="submit" name="submit" value="submit"/>
    
                
    
                </div>
    
              
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
          
          
          
          
          </form>
          

    

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>