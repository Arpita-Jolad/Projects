<?php
include('dbconnect.php');
$sql=mysqli_query($conn,"SELECT * FROM ENQUIRY");

?>
<html>
    <head>
        <title>
            "ENQUIRY DETAILS"
        </title>
    </head>
    <body>
    <table border=2 >
        <tr>
           <td>MAID_ID</td>
           <td>MAIDNAME</td>
           <td>CATEGORY</td>
           
          <td>MOBILE</td>
           <td>CITY</td>
           <td>ADDRESS</td>
           <td>WORK_DETAILS</td>
           <td>PRICING</td>
           <td>USER_FN</td>
            <td>USER_LN</td>
             <td>USER_MNO</td>
        </tr>
 <?php
 while($row=mysqli_fetch_array($sql))
{
    $V1=$row['MAID_ID'];
    $V2=$row['MAIDNAME'];
    $V3=$row['CATEGORY'];
   
    $V4=$row['MOBILE'];
    $V5=$row['CITY'];
    $V6=$row['ADDRESS'];
    $V7=$row['WORK_DETAILS'];
     $V8=$row['PRICING'];
      $V9=$row['USER_FN'];
       $V10=$row['USER_LN'];
          $V11=$row['USER_MNO'];
                                                
?>

<tr>
  <td><?php echo $V1; ?> </td>
  <td> <?php echo $V2; ?></td>
   <td> <?php echo $V3; ?></td>
    <td> <?php echo $V4; ?></td>
    <td> <?php echo $V5; ?></td>
   <td> <?php echo $V6; ?></td>
    <td> <?php echo $V7; ?></td>
     <td> <?php echo $V8; ?></td>
      <td> <?php echo $V9; ?></td>
       <td> <?php echo $V10; ?></td>
        <td> <?php echo $V11; ?></td>
         
     </tr>
      
      <?php
}
?>
</table>
</body>
</html>
 