<?php

include('db_connect.php');
 
$v1=$_REQUEST['f1'];
$v2=$_REQUEST['f2'];
$v3=$_REQUEST['f3'];
$v4=$_REQUEST['f4'];
$v5=$_REQUEST['f5'];
$v6=$_REQUEST['f6'];
$v7=$_REQUEST['f7'];

 
 
$response = array();
 
$sql=mysqli_query($conn,"UPDATE MAID SET FIRSTNAME='$v1',LASTNAME='$v2',EMAIL='$v3',PASSWORD='$v4',CITY='$v6',POSTALADDRESS='$v7' WHERE MOBILENO='$v5'");

 
if ( $sql == TRUE)
{
    $response["success"] = 1;
    $response["message"] = "  successfully.";
    echo json_encode($response);
    
}
else
{
    $response["success"] = 0;
    $response["message"] = "  failed.";
    echo json_encode($response);
}

?>