<?php

include('db_connect.php'); 
$v1=$_REQUEST['f1'];

 
$output=array();

 
$result=mysqli_query($conn,"SELECT * FROM MAID_DETAILS WHERE M_NAME='$v1'");

$cnt=0;

while($r=mysqli_fetch_array($result))
{
    $cnt=1;
    $output[]=array("MAID_ID"=>$r["MAID_ID"],"M_NAME"=>$r["M_NAME"],"CATEGORY"=>$r["CATEGORY"],"MOBILE"=>$r["MOBILE"],"CITY"=>$r["CITY"],"ADDRESS"=>$r["ADDRESS"],"WORK_DETAILS"=>$r["WORK_DETAILS"],"PRICING"=>$r["PRICING"]);       
}

  
$flag["code"]="0";

if($cnt>0)
{
    $flag["code"]="1";
    
    print(json_encode($output));
}
else
{   
    printf(json_encode("Error"));

} 

 

?>