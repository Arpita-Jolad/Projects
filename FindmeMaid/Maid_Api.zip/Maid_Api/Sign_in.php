<?php

include('db_connect.php');
 
$V1=$_REQUEST['f1'];
$V2=$_REQUEST['f2'];
$V3=$_REQUEST['f3'];
$V4=$_REQUEST['f4'];
$V5=$_REQUEST['f5'];
$V6=$_REQUEST['f6'];
$V7=$_REQUEST['f7'];
    

 
 
$response = array();
 
$sql=mysqli_query($conn,"INSERT INTO MAID VALUES('$V1','$V2','$V3','$V4','$V5','$V6','$V7')");

 
if ( $sql == TRUE)
{
    $response["success"] = 1;
    $response["message"] = " successfully.";
    echo json_encode($response);
    
}
else
{
    $response["success"] = 0;
    $response["message"] = "  failed.";
    echo json_encode($response);
}

?>