<?php

include('db_connect.php'); 
$v1=$_REQUEST['f1'];

 
$output=array();

 
$result=mysqli_query($conn,"SELECT M_NAME FROM MAID_DETAILS WHERE CATEGORY='$v1'");

$cnt=0;

while($r=mysqli_fetch_array($result))
{
    $cnt=1;
    $output[]=array("M_NAME"=>$r["M_NAME"]);       
}

  
$flag["code"]="0";

if($cnt>0)
{
    $flag["code"]="1";
    
    print(json_encode($output));
}
else
{   
    printf(json_encode("Error"));

} 

 

?>