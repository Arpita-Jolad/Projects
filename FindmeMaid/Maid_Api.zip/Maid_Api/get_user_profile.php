<?php

include('db_connect.php'); 
$v1=$_REQUEST['f1'];
 
$output=array();

 
$result=mysqli_query($conn,"SELECT * FROM MAID WHERE MOBILENO=('$v1')");

$cnt=0;

while($r=mysqli_fetch_array($result))
{
    $cnt=1;
    $output[]=array("FIRSTNAME"=>$r["FIRSTNAME"],
    "LASTNAME"=>$r["LASTNAME"],
    "EMAIL"=>$r["EMAIL"],
    "PASSWORD"=>$r["PASSWORD"],
    "MOBILENO"=>$r["MOBILENO"],
    "CITY"=>$r["CITY"],
    "POSTALADDRESS"=>$r["POSTALADDRESS"]);
      
}

  
$flag["code"]="0";

if($cnt>0)
{
    $flag["code"]="1";
    
    print(json_encode($output));
}
else
{   
    printf(json_encode("Error"));

} 

 

?>